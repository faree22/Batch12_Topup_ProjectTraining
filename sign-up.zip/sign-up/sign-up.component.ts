import { Component, OnInit } from '@angular/core';
import { FormGroup, FormControl, Validators } from '@angular/forms';
@Component({
  selector: 'app-sign-up',
  templateUrl: './sign-up.component.html',
  styleUrls: ['./sign-up.component.css']
})
export class SignUPComponent implements OnInit {
  public SignupForm : FormGroup
  constructor() { 
    
   }
   user={
    useradm:'',
    username:'',
    email:'',
    mobile:'',
    password:''
   };

  ngOnInit(): void {
    this.SignupForm= new FormGroup({
      'useradm':new FormControl(null,Validators.required),
      'username':new FormControl(null,Validators.required),
      'email':new FormControl(null,[Validators.required,Validators.email]),
      'mobile':new FormControl(null,Validators.required),
      'password':new FormControl(null,Validators.required)
    })
  }
 onSubmit(){
    this.user.useradm=this.SignupForm.value.useradm;
    this.user.username=this.SignupForm.value.username;
    this.user.email=this.SignupForm.value.email;
    this.user.mobile=this.SignupForm.value.mobile;
    this.user.password=this.SignupForm.value.password;
 }
  }

